define([`${localStorage['rsDebugUrl_38v8q4vxyplnj27fhp'] || './build/js/app.7e5d08e5.js'}`], m => {
  return function () {
    return m.default(this)
  }
})
